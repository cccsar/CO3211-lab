#Implementacion del metodo de sort

%{
  La funcion toma al error relativo como referencia de parada,
  haciendo que la funcion se detenga cuando el error relativo es
  menor a la tolerancia 
 %}
 
function [k]=sor(A,b,x0,w,tol)
  #Separacion de A en A=D+L+U
  n=length(A);
  D=triu(A)-triu(A,1);
  U=triu(A,1);
  L=tril(A,-1);
  cuenta=1;
  xn=(inv(D-w*L))*((w*U+(1-w)*D)*x0+w*b);
  erel=norm(xn-x0,inf)/norm(xn,inf);
  
  while erel>tol 
    xn=(inv(D-w*L))*((w*U+(1-w)*D)*x0+w*b);
    erel=norm(xn-x0,inf)/norm(xn,inf)  ;
    x0=xn;
    cuenta+=1;
  endwhile
  
  x=xn;
  k=cuenta;
endfunction
  