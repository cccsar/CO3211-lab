#Ejercicio1
%{
#Calculos A1: 

X=-1+(2)*rand(10,10);

A1=X+10*eye(10,10);

b1=A1*ones(10,1);

x0=0*ones(10,1);
maxit=1000;
tol=10^-13;

#Calculos A2: 

Y=-1+(2)*rand(20,20);

A2=Y.'*Y+(10^-3)*eye(20,20);

b2=A2*ones(20,1)
x1=0*ones(20,1);

#Soluciones:

[xn1 k1]=jacobi(A1,b1,x0,maxit,tol)
Mi1=matriziteracion(A1,0);
re1=max(abs(eig(Mi1)))

[xv1 k11]=gauss_seidel(A1,b1,x0,maxit,tol)
Mi2=matriziteracion(A1,1);
re2=max(abs(eig(Mi2)))


[xn2 k2]=jacobi(A2,b2,x1,maxit,tol)
Mi3=matriziteracion(A2,0);
re3=max(abs(eig(Mi3)))

[xv2 k22]=gauss_seidel(A2,b2,x1,maxit,tol)
Mi4=matriziteracion(A2,1);
re4=max(abs(eig(Mi4)))



#Ejercicio2
%}

#Matrices dadas:
M1=[7 3 -1 2 ; 3 8 1 -4 ; -1 1 4 -1 ; 2 -4 -1 6];
j=[-1;0;-3;1];

M2=[4 3 0;3 4 -1; 0 -1 4];
k=ones(3,1);

tol=10^-13;

xaux=0*ones(4,1);
xaux1=0*ones(3,1);

#Graficas:

%{
  Se utiliza el siguiente for para crear dos lista de los resultados 
  de la funcion SOR sobre cada valor dado de W. Cada lista corresponde 
  a una de las matrices dadas
%}
imag=[]
for w=100:1:19900
  imag(w)=sor(M1,j,xaux,w/(10^4),tol);
  imag2(w)=sor(M2,k,xaux1,w/(10^4),tol);
  #plot(w,sor(M2,k,xaux1,w,tol))
endfor

w=100:1:19900

#Grafica 1:

tic();
plot(w,imag(w))
tiempog1=toc()

hold on

#Grafica 2:

tic();
plot(w,imag2(w))
tiempog2=toc()






