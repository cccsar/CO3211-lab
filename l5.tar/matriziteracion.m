%{
  Funcion que calcula el radio espectral de la matriz de iteracion para los 
  metodos de Jacobi o Gauss Seidel. Se basa en los teoremas: 
  
    GaussSeidel:  respectral(D^-1(L+U)<1) == La matriz de Seidel converge
    
    Jacobi: respectral(N^-1*P<1) == La matriz de Jacobi converge
    
    En donde: 
    
    D=diagonal principal
    L=diagonal inferior 
    U=diagonal superior 
    N=(D+U)^-1
    P=-L
   
%}

function r=matriziteracion(A,m)
    D=triu(A)-triu(A,1);
    L=triu(A);
    U=tril(A);
  if m==0
    r=inv(D)*(L+U);
  elseif m==1
    r=inv(D+U)*(-L);
  endif
endfunction
